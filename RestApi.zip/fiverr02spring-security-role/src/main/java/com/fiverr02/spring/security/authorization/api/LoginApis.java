package com.fiverr02.spring.security.authorization.api;

import lombok.AllArgsConstructor;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.security.Principal;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@Validated
@AllArgsConstructor
public class LoginApis {



    @RequestMapping(value ="/login",method = RequestMethod.POST)
    public boolean login(@RequestBody User user) {
    	System.out.println(user.getName().toString());
    	System.out.println(user.getPassword().toString());
        return
          user.getName().equals("user") && user.getPassword().equals("password");
        
    }
	
    @RequestMapping(value="/user",method = RequestMethod.GET)
    public Object user(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization")
          .substring("Basic".length()).trim();
        
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof UserDetails) {
          String username = ((UserDetails)principal).getUsername();
          Collection<? extends GrantedAuthority> role= ((UserDetails)principal).getAuthorities() ;
          
        }
        return principal;

        }
     
    
    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("http://localhost:4200/"));
        configuration.setAllowedMethods(Arrays.asList("*"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
    }





 

