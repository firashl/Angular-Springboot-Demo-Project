package com.fiverr02.spring.security.authorization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityRoleBasedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityRoleBasedApplication.class, args);
	}



}
