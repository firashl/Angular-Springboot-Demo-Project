package com.fiverr02.spring.security.authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityRoleBasedApplicationTests {

	@Test
	void contextLoads() {
	}

}
