# Fiverr Platform

User: has two users:
1. user
2. admin

Following roles are available:
1. USER
2. ADMIN

The user and roles are setup in SecurityConfigurer as shown below:

**_NOTE:_** User & Roles can be setup by gettting the information from DB

```java
   @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {

        auth.inMemoryAuthentication()
                .withUser("user").password("{noop}password").roles("USER")
                .and()
                .withUser("admin").password("{noop}password").roles("USER", "ADMIN");}
```
API/REST roles based access has been setup as shown below:


```java
     @Override
    protected void configure(HttpSecurity http) 
      throws Exception {
        http.csrf().disable()
          .authorizeRequests()
          .antMatchers("/login").permitAll()
          .anyRequest()
          .authenticated()
          .and()
          .httpBasic();
    }


## Run application

```bash
mvn spring-boot:run

```

## Demo
## Post login user credentials

_**Request**_
```bash
curl localhost:8081/login

```
_**Output**_
```true or false
```


### GET user credentials

_**Request**_
```bash
curl localhost:8081/user

```
_**Output**_
```json
{"password":null,"username":"admin","authorities":[{"authority":"ROLE_ADMIN"},{"authority":"ROLE_USER"}],"accountNonExpired":true,"accountNonLocked":true,"credentialsNonExpired":true,"enabled":true}
```

### 
# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.2.RELEASE/maven-plugin/)
* [Spring Security](https://docs.spring.io/spring-boot/docs/2.2.2.RELEASE/reference/htmlsingle/#boot-features-security)
* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/2.2.2.RELEASE/reference/htmlsingle/#boot-features-jpa-and-spring-data)

### Guides
The following guides illustrate how to use some features concretely:

* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and Angular authentification](https://www.baeldung.com/spring-security-login-angular)


